# GitDigital Content Delivery Network (CDN)

High-availability asset distribution for the GitDigital Fintech Ecosystem.

## Overview

This repository serves as the backbone for content delivery across the GitDigital platform. It provides a scalable, high-performance Content Delivery Network (CDN) infrastructure for serving static assets, JavaScript SDKs, and styling resources.

## Features

- **Global Edge Network**: Assets are distributed across multiple edge locations worldwide
- **Automatic Optimization**: Assets are automatically compressed using WebP and AVIF formats
- **Minification**: All assets are minified for optimal performance
- **Immutable Caching**: Cache headers set to immutable for 1 year to reduce latency
- **Version Control**: All assets are tracked and versioned for consistency

## Usage

### Base URL

All assets are served via the global edge network using the following URL structure:

```
https://cdn.gitdigital.products/[category]/[filename]
```

### Categories

Assets are organized into the following categories:

- **assets**: Branding, icons, UI elements (SVG, PNG, JPG)
- **scripts**: Production-ready JavaScript SDKs
- **styles**: Global CSS themes and design tokens

### Examples

```html
<!-- Using an icon -->
<img src="https://cdn.gitdigital.products/assets/logo.svg" alt="GitDigital Logo">

<!-- Using JavaScript SDK -->
<script src="https://cdn.gitdigital.products/scripts/sdk.min.js"></script>

<!-- Using CSS styles -->
<link rel="stylesheet" href="https://cdn.gitdigital.products/styles/theme.css">
```

## Project Structure

```
Content-Distribution-Networks-CDNs-/
├── assets/                 # Branding, icons, UI elements
│   ├── logo.svg          # Main logo
│   └── icons/             # UI icons and favicons
├── scripts/              # Production-ready JavaScript SDKs
│   └── sdk.min.js        # Main JavaScript SDK
├── styles/               # Global CSS themes and design tokens
│   └── theme.css         # Global CSS theme
├── index.html            # Landing page for direct CDN visits
├── manifest.json         # Asset manifest
└── package.json          # Node.js configuration
```

## Contributing Guidelines

We welcome contributions to improve the CDN infrastructure. Please follow these guidelines:

### Naming Conventions

- Use **kebab-case** for all file and directory names
- Use **.svg** format for icons and logos
- Use descriptive, semantic names

### Asset Requirements

- All images should be optimized and compressed
- JavaScript files must be minified for production
- CSS files should be minified and use CSS variables for theming
- SVG assets should be cleaned and optimized

### Updating Manifest

When adding new assets, always update the `manifest.json` file to include:

- Asset name and path
- Category
- Description
- Cache settings

### Pull Request Process

1. Fork the repository
2. Create a feature branch (`feature/your-feature-name`)
3. Add your assets in the appropriate directories
4. Update the `manifest.json` with new assets
5. Submit a pull request with detailed description

## Performance

### Optimization Techniques

- **Image Compression**: Automatic conversion to WebP and AVIF formats
- **Minification**: All JavaScript and CSS files are minified
- **Caching**: Immutable cache headers set to 1 year (31536000 seconds)
- **CDN Distribution**: Global edge network for low-latency delivery

### Cache Headers

```
Cache-Control: public, max-age=31536000, immutable
```

## Security

- This is a private CDN for internal use only
- All assets are served over HTTPS
- CORS headers are configured for authorized domains only
- See [SECURITY.md](SECURITY.md) for security policies

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For issues and questions:

- Open an issue on GitHub
- Contact the GitDigital team through official channels

## Related Projects

- [GitDigital Main Platform](https://gitdigital.products)
- [GitDigital Documentation](https://docs.gitdigital.products)

---

**Note**: This CDN is optimized for the GitDigital Fintech Ecosystem and is intended for internal use.
