# Security Policy

## Supported Versions

We actively maintain and provide security updates for the following versions:

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability within this CDN project, please send an email to security@gitdigital.products. All security vulnerabilities will be promptly addressed.

Please include the following information:

- Type of vulnerability
- Full paths of source file(s) related to the vulnerability
- Location of the affected source code
- Any special configuration required to reproduce the issue
- Step-by-step instructions to reproduce the issue
- Proof-of-concept or exploit code (if possible)
- Impact of the issue, including how an attacker might exploit it

## Security Measures

### Data Protection

- All assets are served over HTTPS only
- CORS headers are configured to restrict access to authorized domains
- No sensitive data is stored in this repository
- Assets are served from edge locations with DDoS protection

### Access Control

- This is a private CDN intended for internal use
- Access is restricted to authorized GitDigital domains
- API keys and credentials are never stored in this repository
- Environment variables are used for configuration management

### Content Security

- All uploaded assets are scanned for malware
- SVG files are sanitized to prevent XSS attacks
- File type validation is enforced on all uploads
- Content-Length headers are validated to prevent request smuggling

### Network Security

- DDoS protection via edge network
- Rate limiting on all endpoints
- IP allowlisting for administrative access
- TLS 1.3 enforced for all connections

## Best Practices

### For Contributors

- Never commit sensitive data or credentials
- Use environment variables for configuration
- Follow secure coding guidelines
- Report any security concerns immediately

### For Users

- Always use HTTPS when accessing assets
- Validate asset integrity using checksums
- Keep your applications updated
- Report any suspicious activity

## Incident Response

In case of a security incident:

1. **Detection**: Identify and confirm the security issue
2. **Containment**: Isolate affected systems
3. **Eradication**: Remove the threat
4. **Recovery**: Restore normal operations
5. **Lessons Learned**: Document and improve

## Contact

For security-related inquiries, please contact:

- Email: security@gitdigital.products
- Website: https://gitdigital.products/security

## Acknowledgments

We appreciate the efforts of security researchers who help us maintain the security of our CDN infrastructure.
